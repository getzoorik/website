# Tagline

## Reduce cloud cost, autonomously.

The owner, 15 Oct 2026 (D203): "Reduce cloud cost Autonomously will be the tag brand identity".

**How it is written**
- Use exactly these words, in this order: "Reduce cloud cost, autonomously."
- It's in sentence case, with a comma before "autonomously" and a full stop at the end, as it already reads on zoorik.com and Medium.
- It's "cost", not "costs".

**Never**
- Don't reword it: not "Reducing cloud cost autonomously", "Autonomously reduce cloud cost", "automatically" or "continuously".
- Don't add a figure, a product name or a second clause to it.

**Where it goes**
- Everywhere the brand speaks: under or beside the logo, the website, banners, profiles, decks and posts.
- It is one line, repeated the same way every time. That repetition is what makes people remember it.
