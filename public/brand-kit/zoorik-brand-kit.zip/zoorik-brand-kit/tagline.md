# Tagline

## Reduce cloud cost, autonomously.

The owner, 15 Oct 2026 (D203): "Reduce cloud cost Autonomously will be the tag brand identity".

**How it is written**
- Use exactly these words, in this order: "Reduce cloud cost, autonomously."
- It's in sentence case, with a comma before "autonomously" and a full stop at the end, as it already reads on zoorik.com and Medium.
- It's "cost", not "costs".

**Never**
- Don't reword it: not "Reducing cloud cost autonomously", "Autonomously reduce cloud cost", "automatically" or "continuously".
- Don't add a figure, a product name or a second clause to it.

**Where it goes**
- Wherever the brand speaks to people: under or beside the logo, banners, profiles, decks, posts and the website's home page.
- It is one line, repeated the same way every time. That repetition is what makes people remember it.
- Page titles, meta descriptions, the company markup and the first line of an "about" text carry the company line instead: "Zoorik is a cloud cost optimization company." (owner, 18 Oct 2026). Use the two lines strategically, never one line everywhere.

## The name and the tagline as one heading

The owner, 15 Oct 2026 (the home page H1, live on zoorik.com since 16 Oct). The name goes on its own line above the tagline, so a page heading names the company without touching the tagline.

- **Two lines, in this order.** First the name "Zoorik" as a small line, then the tagline, unchanged in its words, size and place.
- **The name is text, not the logo.** Write "Zoorik" with a capital Z, in the page's own typeface, with no uppercase transform. The lowercase "zoorik" belongs to the logo only.
- **The name is smaller and quieter than the tagline.** On zoorik.com it is 14 px, weight 500, letter-spacing 0.01 em, line height 1.4, at 72% of the heading's colour, 14 px above the tagline.
- **Both lines are one heading.** In HTML: `<h1><span class="hero-name" translate="no">Zoorik</span> Reduce cloud cost, autonomously.</h1>`, with the name shown as a block. Keep the space after the name, so that search engines and screen readers read "Zoorik Reduce cloud cost, autonomously.".
- **The tagline never takes the name into its own words.** Not "Zoorik reduces cloud cost, autonomously." and not "Zoorik: Reduce cloud cost, autonomously."
- **Why:** a heading is the strongest signal of what a page is about, and the name in it helps "zoorik" find zoorik.com in search.
