Zoorik brand kit (brand 2.0, 15 Oct 2026)

Colours: navy #050B3D (RGB 5, 11, 61) and bone #FAF7F3 (RGB 250, 247, 243). White is only the page the navy logo sits on.
One colour, always: bone on navy, or navy on white.
Clear space: one core diameter (0.434 of the mark's height) on every side.
Sizes: the full mark from 33 px; the whole logo at least 69 px wide; the small mark only at 32 px and below.
Never stretch, rotate, outline, recolour, retype or add shadows to the logo; never move the mark against the word;
never place it on photographs or busy patterns.

Tagline: Reduce cloud cost, autonomously.
Company line: Zoorik is a cloud cost optimization company.

About Zoorik: Zoorik is a cloud cost optimization company. Coral rebalances Kubernetes on AKS and EKS. Amoeba rightsizes block storage: Azure managed disks and Amazon EBS. Both work autonomously, without any downtime, and show what you spend and what you save. Start with the free assessment at zoorik.com/assessment. Zoorik Private Limited, Bangalore, India.

Fonts: Fira Sans Medium (the word) and Regular (the tagline), SIL Open Font License, in fonts/.
Questions: founders@zoorik.com
